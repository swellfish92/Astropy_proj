from sympy import Symbol, solve
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


class object:
    def __init__(self, initial_temp, rho, Cp, k, Area, thickness, edge_cond):
        self.temp = initial_temp
        self.rho = rho
        self.Cp = Cp
        self.k = k
        self.Area = Area
        self.thickness = thickness
        self.volume = Area * thickness
        self.edge_cond = edge_cond

        if edge_cond == True:
            self.volume = self.volume * 0.5

        self.q_in = []
        self.q_out = []

    def update_temp(self):
        # in/out 어레이의 값을 가지고 비체적을 통해 온도변화를 반영한 뒤, 어레이 값을 초기화
        self.delta_q = sum(self.q_in) - sum(self.q_out)
        self.temp = self.temp + self.delta_q /(self.rho * self.Cp * self.volume)
        self.q_in = []
        self.q_out = []

# class t_con:
#     def __init__(self, obj_a, obj_b):
#         self.object_a = obj_a
#         self.object_b = obj_b
# 
# 
# class t_con_conv(t_con):
#     def __init__(self, obj_a, obj_b):
#         super(t_con, self).__init__(obj_a, obj_b)
# 
# class t_con_cond(t_con):
#     def __init__(self, obj_a, obj_b):
#         super(t_con, self).__init__(obj_a, obj_b)
#     def process(self):
#         if self.obj_a.temp > self.obj_b.temp:
#             self.obj_a.q_out.append(self.obj_a.k * (self.obj_a - self.obj_b) / ((self.obj_a.thickness + self.obj_b.thickness)*0.5))
#             self.obj_b.q_in.append(self.obj_b.k * (self.obj_a - self.obj_b) / ((self.obj_a.thickness + self.obj_b.thickness) * 0.5))
#         elif self.obj_b.temp > self.obj_a.temp:
#             self.obj_b.q_out.append(self.obj_b.k * (self.obj_b - self.obj_a) / ((self.obj_a.thickness + self.obj_b.thickness) * 0.5))
#             self.obj_a.q_in.append(self.obj_a.k * (self.obj_b - self.obj_a) / ((self.obj_a.thickness + self.obj_b.thickness) * 0.5))
# class t_con_rad(t_con):
#     def __init__(self, obj_a, obj_b):
#         super(t_con, self).__init__(obj_a, obj_b)

def process_cond(obj_a, obj_b):
    if obj_a.temp > obj_b.temp:
        obj_a.q_out.append(
            obj_a.k * (obj_a.temp - obj_b.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_a.Area)
        obj_b.q_in.append(
            obj_b.k * (obj_a.temp - obj_b.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_a.Area)
    elif obj_b.temp > obj_a.temp:
        obj_b.q_out.append(
            obj_b.k * (obj_b.temp - obj_a.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_b.Area)
        obj_a.q_in.append(
            obj_a.k * (obj_b.temp - obj_a.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_b.Area)
    else:
        pass

def process_teg(obj_a, obj_b):
    # teg case를 가정하고 진행함. 설정에 주의할 것

    if obj_a.temp > obj_b.temp:
        # 여러 종류 teg를 쓰지는 않으니까, 일단 하나로 가정하고 속성값은 함수 내부에서 정의해 사용
        alpha = Q_max * (obj_a.temp - dt_max) / (count_thermocouple * obj_a.temp**2 * I_max)
        # f_p 값은 우선 0.5로 둔다... (뭔지 잘 모름)
        f_p = 0.5
        rho = obj_a.Area * f_p *(obj_a.temp - dt_max) ** 2 / (2*obj_a.temp**2*obj_a.thickness)
        delta_t = obj_a.temp - obj_b.temp
        I_teg = alpha * delta_t / (R_load + R_teg)
        V_teg = count_thermocouple * alpha * delta_t / ((R_load/R_teg + 1) * R_load/R_teg)

        # 발전량
        P = I_teg * V_teg
        # 흡열량
        q_c = count_teg * count_thermocouple * (alpha * I_teg * obj_a.temp - 0.5 * I_teg ** 2 * R_teg + K_teg * delta_t)
        obj_a.q_out.append(
            obj_a.k * (obj_a.temp - obj_b.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_a.Area)
        obj_b.q_in.append(
            obj_b.k * (obj_a.temp - obj_b.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_a.Area)
    elif obj_b.temp > obj_a.temp:
        obj_b.q_out.append(
            obj_b.k * (obj_b.temp - obj_a.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_b.Area)
        obj_a.q_in.append(
            obj_a.k * (obj_b.temp - obj_a.temp) / ((obj_a.thickness + obj_b.thickness) * 0.5) * obj_b.Area)
    else:
        pass

a = object(100, 1, 1, 1, 1, 4, False)
b = object(200, 1, 1, 1, 1, 4, False)

for i in range(20):
    process_cond(a, b)
    a.update_temp()
    b.update_temp()
    print(a.temp)
    print(b.temp)
    # print(a.q_in, a.q_out)
    # print(b.q_in, b.q_out)
    print('------------------')



process_cond(a, b)


